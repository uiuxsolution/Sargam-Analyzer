import librosa
import numpy as np
from tkinter import Tk, Button, Label, filedialog, ttk, Frame, Text, Scrollbar
from typing import List, Tuple
import threading
import time
import speech_recognition as sr

class SargamAnalyzer:
    def __init__(self):
        # Initialize speech recognizer
        self.recognizer = sr.Recognizer()
        
        # Define frequency ranges for each note (in Hz)
        # These are approximate ranges for middle octave
        self.note_ranges = {
            'Sa': (240, 260),   # C
            'Re': (270, 290),   # D
            'Ga': (300, 320),   # E
            'Ma': (320, 340),   # F
            'Pa': (360, 380),   # G
            'Dha': (400, 420),  # A
            'Ni': (440, 460),   # B
            'Sa2': (480, 500)   # Higher C
        }
        self.current_note = None

    def analyze_audio(self, file_path: str) -> Tuple[List[str], float]:
        """Analyze the audio file and return sequence of sargam notes and duration."""
        try:
            # Load the audio file
            y, sr = librosa.load(file_path)
            duration = librosa.get_duration(y=y, sr=sr)
            
            # Extract pitch using librosa
            pitches, magnitudes = librosa.piptrack(y=y, sr=sr)
            
            # Get the most prominent pitch at each time
            pitch_sequence = []
            for time_idx in range(pitches.shape[1]):
                pitches_t = pitches[:, time_idx]
                mags_t = magnitudes[:, time_idx]
                if len(pitches_t[mags_t > 0]) > 0:
                    pitch_sequence.append(pitches_t[mags_t.argmax()])
            
            # Convert frequencies to notes
            notes = self._frequencies_to_notes(pitch_sequence)
            # Generate lyrics
            lyrics = self._generate_lyrics(file_path)
            
            return notes, duration, lyrics
            
        except Exception as e:
            print(f"Error analyzing audio: {str(e)}")
            return [], 0, ""

    def _frequencies_to_notes(self, frequencies: List[float]) -> List[str]:
        """Convert frequencies to sargam notes."""
        notes = []
        for freq in frequencies:
            note = 'Silent'
            for note_name, (low, high) in self.note_ranges.items():
                if low <= freq <= high:
                    note = note_name
                    break
            if note != 'Silent':
                notes.append(note)
        
        # Remove consecutive duplicates
        return [notes[i] for i in range(len(notes)) 
                if i == 0 or notes[i] != notes[i-1]]
                
    def _generate_lyrics(self, file_path: str) -> str:
        """Generate lyrics from the audio file using speech recognition with Hindi language support."""
        try:
            # Convert MP3 to WAV format for speech recognition
            y, sr = librosa.load(file_path, sr=16000)  # Use 16kHz sampling rate for better speech recognition
            import io
            import soundfile as sf
            wav_io = io.BytesIO()
            sf.write(wav_io, y, sr, format='WAV', subtype='PCM_16')
            wav_io.seek(0)
            
            with sr.AudioFile(wav_io) as source:
                print("Recording audio from file...")
                audio = self.recognizer.record(source)
                print("Attempting speech recognition...")
                # Try Hindi first, then English if Hindi fails
                try:
                    print("Attempting Hindi recognition...")
                    lyrics = self.recognizer.recognize_google(audio, language='hi-IN')
                    print(f"Hindi lyrics detected: {lyrics}")
                except sr.UnknownValueError:
                    print("Hindi recognition failed, attempting English...")
                    # If Hindi recognition fails, try English
                    lyrics = self.recognizer.recognize_google(audio, language='en-US')
                    print(f"English lyrics detected: {lyrics}")
                return lyrics
        except Exception as e:
            print(f"Error generating lyrics: {str(e)}")
            import traceback
            print(f"Detailed error: {traceback.format_exc()}")
            return ""

class SargamGUI:
    def __init__(self):
        self.window = Tk()
        self.window.title("Sargam Note Analyzer")
        self.window.geometry("600x400")
        
        self.analyzer = SargamAnalyzer()
        self.current_file = None
        self.is_playing = False
        
        # Create GUI elements
        self.setup_gui()

    def setup_gui(self):
        # Upload button
        self.upload_btn = Button(
            self.window,
            text="Upload MP3",
            command=self.upload_file
        )
        self.upload_btn.pack(pady=20)
        
        # Progress bar
        self.progress_frame = Frame(self.window)
        self.progress_frame.pack(fill='x', padx=20)
        
        self.progress_bar = ttk.Progressbar(
            self.progress_frame,
            orient='horizontal',
            mode='determinate'
        )
        self.progress_bar.pack(fill='x', expand=True)
        
        # Play/Stop button
        self.play_btn = Button(
            self.window,
            text="Play",
            command=self.toggle_playback,
            state='disabled'
        )
        self.play_btn.pack(pady=10)
        
        # Notes display frame
        self.notes_frame = Frame(self.window)
        self.notes_frame.pack(pady=20)
        
        # Create note labels
        self.note_labels = {}
        for note in ['Sa', 'Re', 'Ga', 'Ma', 'Pa', 'Dha', 'Ni', 'Sa2']:
            label = Label(
                self.notes_frame,
                text=note,
                width=6,
                relief='ridge',
                padx=5,
                pady=5
            )
            label.pack(side='left', padx=2)
            self.note_labels[note] = label
        
        # Lyrics text widget
        self.lyrics_frame = Frame(self.window)
        self.lyrics_frame.pack(fill='both', expand=True, padx=20)
        
        self.lyrics_text = Text(self.lyrics_frame, height=4, wrap='word')
        self.lyrics_text.pack(side='left', fill='both', expand=True)
        
        scrollbar = Scrollbar(self.lyrics_frame)
        scrollbar.pack(side='right', fill='y')
        
        self.lyrics_text.config(yscrollcommand=scrollbar.set)
        scrollbar.config(command=self.lyrics_text.yview)
        
        # Result label
        self.result_label = Label(
            self.window,
            text="Upload an MP3 file to see the Sargam notes",
            wraplength=550
        )
        self.result_label.pack(pady=20)

    def highlight_note(self, note):
        # Reset all labels
        for label in self.note_labels.values():
            label.configure(bg='SystemButtonFace')
        
        # Highlight current note
        if note in self.note_labels:
            self.note_labels[note].configure(bg='yellow')

    def upload_file(self):
        file_path = filedialog.askopenfilename(
            filetypes=[("MP3 files", "*.mp3")]
        )
        
        if file_path:
            self.current_file = file_path
            self.result_label.config(text="Analyzing...")
            self.window.update()
            
            # Analyze the file
            self.notes, self.duration, self.lyrics = self.analyzer.analyze_audio(file_path)
            
            # Update lyrics display
            self.lyrics_text.delete('1.0', 'end')
            if self.lyrics:
                self.lyrics_text.insert('1.0', self.lyrics)
            
            # Enable play button if notes were found
            if self.notes:
                self.play_btn.configure(state='normal')
                result_text = "Ready to play! Click Play to start."
            else:
                result_text = "Could not detect notes. Please try another file."
            
            self.result_label.config(text=result_text)

    def toggle_playback(self):
        if not self.is_playing:
            self.is_playing = True
            self.play_btn.configure(text="Stop")
            threading.Thread(target=self.play_sequence, daemon=True).start()
        else:
            self.is_playing = False
            self.play_btn.configure(text="Play")

    def play_sequence(self):
        if not self.notes:
            return

        # Load and play the audio file
        y, sr = librosa.load(self.current_file)
        import sounddevice as sd
        sd.play(y, sr)

        total_steps = len(self.notes)
        step_duration = self.duration / total_steps

        for i, note in enumerate(self.notes):
            if not self.is_playing:
                sd.stop()
                break

            # Update progress bar
            progress = (i / total_steps) * 100
            self.progress_bar['value'] = progress

            # Highlight current note
            self.window.after(0, self.highlight_note, note)

            # Update result label
            current_sequence = " → ".join(self.notes[:i+1])
            self.result_label.config(text=f"Current Sequence:\n{current_sequence}")

            # Wait for the note duration
            time.sleep(step_duration)

        if self.is_playing:
            self.is_playing = False
            self.play_btn.configure(text="Play")
            self.progress_bar['value'] = 0
            # Reset highlighting
            self.window.after(0, self.highlight_note, None)
            sd.stop()

    def run(self):
        self.window.mainloop()

if __name__ == "__main__":
    app = SargamGUI()
    app.run()